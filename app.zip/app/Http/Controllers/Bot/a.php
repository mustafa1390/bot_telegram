// --------

//                     $filePath = storage_path('/upload/telegram/'.$fileName);

// $ch = curl_init();

// curl_setopt($ch, CURLOPT_URL, 'https://irpay.pro/api/user/upload');
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
// curl_setopt($ch, CURLOPT_POST, true);

// curl_setopt($ch, CURLOPT_POSTFIELDS, [
//     'image' => new CURLFile($filePath, mime_content_type($filePath), $fileName),
//     'token' => 'Amer*&uioKOp345!ghJloPPde5&ds',
// ]);

// $response = curl_exec($ch);

// if (curl_errno($ch)) {
// } else {
// }

// curl_close($ch);
                    // --------


                    // Send confirmation




test_send